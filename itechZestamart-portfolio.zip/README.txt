itechZestamart Portfolio

This package contains a single-file portfolio page for the itechZestamart full-stack e-commerce project.

Files:
- itechZestamart-portfolio.html  → The portfolio site
- itechZestamart-hero.png        → Placeholder hero image (replace with your collage)
- README.txt                     → Instructions

How to use:
1. Replace itechZestamart-hero.png with your real hero collage screenshot.
2. Open itechZestamart-portfolio.html in a text editor and update:
   - HERO_IMAGE_SRC → set to itechZestamart-hero.png
   - Live Demo / GitHub links in the header buttons
3. Deploy:
   - GitHub Pages: commit and push, enable Pages in repo settings.
   - Netlify/Vercel: drag & drop the HTML (and image) to dashboard.

Enjoy your new portfolio!